"use strict";

var global = this;

use([], function () {
    return {
        cssClasses: "",
        resourcePath: global.granite.resource.path
    };
});
